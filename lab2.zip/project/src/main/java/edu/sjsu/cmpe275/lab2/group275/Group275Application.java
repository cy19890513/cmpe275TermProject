package edu.sjsu.cmpe275.lab2.group275;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Group275Application {

    public static void main(String[] args) {
        SpringApplication.run(Group275Application.class, args);
    }

}
